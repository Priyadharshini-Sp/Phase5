import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\95\\chromedriver.exe");
		WebDriver wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.amazon.com/");
	   wd.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span")).click();
	   wd.findElement(By.id("ap_email")).sendKeys("k@gmail.com");
	   wd.findElement(By.id("continue")).click();
	   wd.findElement(By.id("ap_password")).sendKeys("1234@c");
	   wd.findElement(By.id("signInSubmit")).submit();
	   wd.close();
	   
	}

}

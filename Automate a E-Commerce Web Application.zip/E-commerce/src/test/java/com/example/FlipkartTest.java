package com.example;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class FlipkartTest {
  @Test
  public void ValidateFlipkart() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\\\95\\\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
	     long start = System.currentTimeMillis();
	    driver.get("https://www.flipkart.com/");
	    long end = System.currentTimeMillis();
	     long r = end-start;
	     System.out.println("Page load time in milliseconds: "+ r);
	    
	    driver.manage().window().maximize();
	    driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
	    System.out.println("===========================");
	    System.out.println("Website Opened!!");
	    
	    
	    
	    driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[3]/a/div[2]")).click();
	    driver.findElement(By.xpath("//input[@class='_3704LK']")).sendKeys("iphone 13");
	    
	    
	    driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[2]/form/div/button")).click();
	    
	    System.out.println("===========================");
	    System.out.println("Mobile search completed");
	    
	    
	    
	    Set<String> Handles = driver.getWindowHandles();
	    
	    for(String actual: Handles)
	    {
	    	driver.switchTo().window(actual);
	    }
	    
	    String execScript = "return document.documentElement.scrollHeight>document.documentElement.clientHeight;";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Boolean test = (Boolean) (js.executeScript(execScript));
		System.out.println("===========================");
		if (test == true) {
			System.out.println("Scrollbar is present.");
		} else if (test == false){
			System.out.println("Scrollbar is not present.");
		}
	  
	  
	    
	    driver.navigate().refresh();
	    
	    System.out.println("===========================");
	    System.out.println("Refresh Done");
	    
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    System.out.println("===========================");
	    System.out.println("Wait Check");
	    
	    
	    js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	    Thread.sleep(9000);
	    System.out.println("===========================");
	    System.out.println("Page scrolled to bottom of the page");
	    
	    js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
	    Thread.sleep(9000);
	    System.out.println("===========================");
	    System.out.println("Page scrolled to top of the page");
	    
	    driver.quit();
	    
	}
  }

